module.exports = {
  TOKEN_GINXJAL: "8539549731:AAHd4e-eafPBdyW0fCuh1ESw45NQiA8b4OQ",
};
