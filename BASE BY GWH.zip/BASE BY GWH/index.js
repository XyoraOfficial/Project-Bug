///CREDIT BASE BY AMBALABU 
/// NO HAPUS CREDIT 
const { Telegraf, Markup, session } = require("telegraf");
const fs = require("fs");
const os = require("os");
const path = require("path");
const ms = require("ms");
const moment = require("moment-timezone");
const {
makeWASocket,
makeInMemoryStore,
fetchLatestBaileysVersion,
useMultiFileAuthState,
DisconnectReason,
generateWAMessageFromContent,
} = require("@whiskeysockets/baileys");

const pino = require("pino");
const chalk = require("chalk");
const axios = require("axios");
const FormData = require("form-data");
const { TOKEN_GINXJAL } = require("./config");
const BOT_TOKEN = TOKEN_GINXJAL;

const MODE_FILE = "./mode.json";
const crypto = require("crypto");

const premiumFile = "./database/premiumuser.json";
const adminFile = "./database/adminuser.json";
const ownerFile = "./database/owneruser.json";
const GROUP_FILE = "./groupmode.json";
const TOKENS_FILE = "./tokens.json";

const sessionPath = "./session";
let bots = [];

const bot = new Telegraf(BOT_TOKEN);
bot.use(session());

global.pairingMessage = null;
let sock = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = "";
let isStarting = false;
let hasConnectedOnce = false;
let reconnectAttempts = 0;

const maxReconnect = 10;
const usePairingCode = true;
// ================= FILE STORAGE ================= //

///// ---- ( GROUP MODE ON / OFF ) ---- /////
function getGroupMode() {
  if (!fs.existsSync(GROUP_FILE)) {
    fs.writeFileSync(GROUP_FILE, JSON.stringify({ group: "off" }, null, 2));
  }
  return JSON.parse(fs.readFileSync(GROUP_FILE)).group;
}

function setGroupMode(group) {
  fs.writeFileSync(GROUP_FILE, JSON.stringify({ group }, null, 2));
}

///// ---- ( BOT MODE: SELF / PUBLIC ) ---- /////
function getMode() {
  try {
    if (!fs.existsSync(MODE_FILE)) return "self";

    const data = JSON.parse(fs.readFileSync(MODE_FILE));
    return data.mode || "self";

  } catch (err) {
    console.error("Error membaca mode:", err);
    return "self";
  }
}

function setMode(newMode) {
  try {
    fs.writeFileSync(MODE_FILE, JSON.stringify({ mode: newMode }, null, 2));
  } catch (err) {
    console.error("Error menyimpan mode:", err);
  }
}


console.log("Current mode:", getMode());

// =============== Coldwdon ====================///
const cooldowns = new Map();

function checkCooldown(ctx, next) {
  const userId = ctx.from.id;
  const now = Date.now();
  const cooldownTime = 1000; 

  if (cooldowns.has(userId)) {
    const expire = cooldowns.get(userId) + cooldownTime;

    if (now < expire) {
      const sisa = ((expire - now) / 1000).toFixed(1);
      return ctx.reply(`⏳ Tunggu ${sisa} detik sebelum pakai command lagi!`);
    }
  }

  cooldowns.set(userId, now);
  return next();
}
// ================= UTIL FUNCTION ================= //

///// ---- ( DATE ) ---- /////
function getCurrentDate() {
  return new Date().toLocaleDateString("id-ID", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

///// ---- ( RUNTIME & MEMORY ) ---- /////
function formatRuntime(seconds) {
  seconds = Number(seconds);

  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  return `${h}h ${m}m ${s}s`;
}

function memory() {
  return (process.memoryUsage().rss / 1024 / 1024).toFixed(0) + " MB";
}
// ================= SECURITY ================= //

/// ----- ( Pasword) --------///

const PASSWORD = "Pelercurut";///ganti password lu , Janggan buta
const userLogin = new Set();

///------ ( Akses jarak jauh On/off in script)
const CONFIG_URL = "https://raw.githubusercontent.com/can6y/security-/refs/heads/main/Keamanan.json";//ganti jadi raw lu

let SECURITY = true; 
let lastHash = ""; 

// ================= CHECK GITHUB SAFE ================= //
async function checkGitHubConfigRealtime() {
  try {
    const res = await axios.get(CONFIG_URL);
    const dataString = JSON.stringify(res.data);

    const hash = crypto.createHash("md5").update(dataString).digest("hex");

    if (hash !== lastHash) {
      lastHash = hash;
      const previousSecurity = SECURITY;
      SECURITY = res.data.SECURITY ?? true;
      console.log("🔐 SECURITY CHANGED:", SECURITY ? "ON" : "OFF");

      if (!SECURITY) {
        console.log("⚠️ Bot OFF / Server Script di non aktifkan oleh @pacenicwlee.");

        
        if (sock && isWhatsAppConnected) {
          try {
            console.log("📴 Logging out WhatsApp safely...");
            await sock.logout(); 
          } catch (err) {
            console.log("⚠️ Gagal logout WA:", err.message);
          } finally {
            
            sock.ev.removeAllListeners?.();
            sock = null;
            isWhatsAppConnected = false;
            console.log("✅ WhatsApp disconnected safely");
          }
        }

      } else {
        console.log("✅ Bot ON / semua fitur kembali aktif.");

        
        if (!sock || !isWhatsAppConnected) {
          try {
            console.log("🔄 Starting WhatsApp session...");
            await startSesi(); 
          } catch (err) {
            console.log("⚠️ Gagal start WhatsApp:", err.message);
          }
        }
      }
    }
  } catch (err) {
    console.log("⚠️ Gagal ambil config GitHub. Pakai status terakhir:", SECURITY ? "ON" : "OFF");
  }
}

// ================= SAFE INTERVAL ================= //

setInterval(() => {
  checkGitHubConfigRealtime().catch(err => {
    console.log("⚠️ Error di checkGitHubConfigRealtime:", err.message);
  });
}, 1000); 

/// ----- ( Function ensureDataBase ) -------- \\\
const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/cannih/database/refs/heads/main/token.json";////ganti jadi Raw luh



async function fetchValidTokens() {
  try {
    const { data } = await axios.get(GITHUB_TOKEN_LIST_URL);
    return Array.isArray(data.tokens) ? data.tokens : [];
  } catch (err) {
    console.log(chalk.red("❌ Gagal mengambil token dari GitHub"));
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("🔍 Memeriksa token..."));

  const validTokens = await fetchValidTokens();

  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("❌ Token tidak valid"));
    process.exit(1);
  }

  console.log(chalk.green("✅ Token valid"));
  startBot();
}



function startBot() {
  console.log(chalk.red(`⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠖⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡤⢤⡀⠀⠀⠀⠀⢸⠀⢱⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⡀⠈⠢⡀⠀⠀⢀⠀⠈⡄⠀⠀⠀⠀⠀⠀⠀⠀⡔⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡤⠊⡹⠀⠀⠘⢄⠀⠈⠲⢖⠈⠀⠀⠱⡀⠀⠀⠀⠀⠀⠀⠀⠙⣄⠈⠢⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⡠⠖⠁⢠⠞⠀⠀⠀⠀⠘⡄⠀⠀⠀⠀⠀⠀⠀⢱⠀⠀⠀⠀⠀⠀⠀⠀⠈⡆⠀⠀⠉⠑⠢⢄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⡠⠚⠁⠀⠀⠀⡇⠀⠀⠀⠀⠀⢀⠇⠀⡤⡀⠀⠀⠀⢀⣼⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⢠⣾⣿⣷⣶⣤⣄⣉⠑⣄⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⠞⢁⣴⣾⣿⣿⡆⢇⠀⠀⠀⠀⠀⠸⡀⠀⠂⠿⢦⡰⠀⠀⠋⡄⠀⠀⠀⠀⠀⠀⠀⢰⠁⣿⣿⣿⣿⣿⣿⣿⣿⣷⣌⢆⠀⠀⠀⠀⠀⠀
⠀⠀⠀⡴⢁⣴⣿⣿⣿⣿⣿⣿⡘⡄⠀⠀⠀⠀⠀⠱⣔⠤⡀⠀⠀⠀⠀⠀⠈⡆⠀⠀⠀⠀⠀⠀⡜⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣮⢣⠀⠀⠀⠀⠀
⠀⠀⡼⢠⣾⣿⣿⣿⣿⣿⣿⣿⣧⡘⢆⠀⠀⠀⠀⠀⢃⠑⢌⣦⠀⠩⠉⠀⡜⠀⠀⠀⠀⠀⠀⢠⠃⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣣⡀⠀⠀⠀
⠀⠀⢰⢃⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⠱⡀⠀⠀⠀⢸⠀⠀⠓⠭⡭⠙⠋⠀⠀⠀⠀⠀⠀⠀⡜⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡱⡄⠀⠀
⠀⠀⡏⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⢃⠀⠀⠀⢸⠀⠀⠀⠀⢰⠀⠀⠀⠀⠀⠀⠀⢀⠜⢁⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠘⣆⠀
⠀⢸⢱⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡘⣆⠀⠀⡆⠀⠀⠀⠀⠘⡄⠀⠀⠀⠀⡠⠖⣡⣾⠁⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⢸⠀
⠀⡏⣾⣿⣿⣿⣿⡿⡛⢟⢿⣿⣿⣿⣿⣿⣿⣧⡈⢦⣠⠃⠀⠀⠀⠀⠀⢱⣀⠤⠒⢉⣾⡉⠻⠋⠈⢘⢿⣿⣿⣿⣿⠿⣿⣿⠏⠉⠻⢿⣿⣿⣿⣿⡘⡆
⢰⡇⣿⣿⠟⠁⢸⣠⠂⡄⣃⠜⣿⣿⠿⠿⣿⣿⡿⠦⡎⠀⠀⠀⠀⠀⠒⠉⠉⠑⣴⣿⣿⣎⠁⠠⠂⠮⢔⣿⡿⠉⠁⠀⠹⡛⢀⣀⡠⠀⠙⢿⣿⣿⡇⡇
⠘⡇⠏⠀⠀⠀⡾⠤⡀⠑⠒⠈⠣⣀⣀⡀⠤⠋⢀⡜⣀⣠⣤⣀⠀⠀⠀⠀⠀⠀⠙⢿⡟⠉⡃⠈⢀⠴⣿⣿⣀⡀⠀⠀⠀⠈⡈⠊⠀⠀⠀⠀⠙⢿⡇⡇
⠀⠿⠀⠀⠀⠀⠈⠀⠉⠙⠓⢤⣀⠀⠁⣀⡠⢔⡿⠊⠀⠀⠀⠀⠙⢦⡀⠀⠐⠢⢄⡀⠁⡲⠃⠀⡜⠀⠹⠟⠻⣿⣰⡐⣄⠎⠀⠀⠀⠀⠀⠀⠀⠀⢣⡇
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠁⠀⡜⠀⠀⠀⠀⠀⠀⠀⠀⠱⡀⠀⠀⠀⠙⢦⣀⢀⡴⠁⠀⠀⠀⠀⠉⠁⢱⠈⢆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⢱⠀⠀⠀⠀⠈⢏⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠈⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠱⡄⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡜⠀⢹⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠘⣆⠀⠀⠀⠀⠀⠀⣰⠃⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡾⠀⠀⠘⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠁⠀⠀⠀⠀⠀⠀⠸⡄⠀⠀⠀⢀⡴⠁⠀⠀⢀⠇⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢧⠀⠀⠀⠘⢆⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⣧⣠⠤⠤⠋⠀⠀⠀⠀⡸⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠢⡀⠀⠀⠀⠳⢄⠀⠀⠀⠀⠀⠀⠀⢣⠀⠀⠀⠀⠀⠀⠀⠀⡏⠀⠀⠀⠀⠀⠀⢀⡴⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡠⠊⠈⠁⠀⠀⠀⡔⠛⠲⣤⣀⣀⣀⠀⠈⢣⡀⠀⠀⠀⠀⠀⢸⠁⠀⠀⠀⢀⡠⢔⠝⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢈⠤⠒⣀⠀⠀⠀⠀⣀⠟⠀⠀⠀⠑⠢⢄⡀⠀⠀⠈⡗⠂⠀⠀⠀⠙⢦⠤⠒⢊⡡⠚⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠆⠒⣒⡁⠬⠦⠒⠉⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠒⢺⢠⠤⡀⢀⠤⡀⠠⠷⡊⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠣⡀⡱⠧⡀⢰⠓⠤⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠁⠀⠈⠃⠀⠀⠀
`))
}

validateToken()

/// ------ Start WhatsApp Session ------ ///
const startSesi = async () => {
  try {
    if (isStarting) return;
    isStarting = true;

    console.log("🚀 Memulai sesi WhatsApp...");

    
    if (sock?.ev) {
      sock.ev.removeAllListeners("connection.update");
      sock.ev.removeAllListeners("creds.update");
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    const { version } = await fetchLatestBaileysVersion();

    sock = makeWASocket({
      version,
      auth: state,
      logger: pino({ level: "silent" }),
      printQRInTerminal: false,

      browser: ["Ubuntu", "Chrome", "20.0.04"],
      keepAliveIntervalMs: 25000, 
      connectTimeoutMs: 60000,
      markOnlineOnConnect: true,

      emitOwnEvents: true,
      fireInitQueries: true, 
    });

    sock.ev.on("creds.update", saveCreds);

    console.log("🔐 Siap pairing / reconnect...");

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;
      const reason = lastDisconnect?.error?.output?.statusCode;

      if (connection === "connecting") {
        console.log("🔄 Connecting...");
      }

      if (connection === "open") {
        isWhatsAppConnected = true;
        isStarting = false;
        hasConnectedOnce = true;
        reconnectAttempts = 0;

        linkedWhatsAppNumber = sock.user?.id?.split(":")[0];

        console.log("✅ WhatsApp Connected:", linkedWhatsAppNumber);

        
        global.pairingMessage = null;
      }

      if (connection === "close") {
        isWhatsAppConnected = false;
        isStarting = false;

        console.log("❌ Disconnected:", reason);

       
        if (reason === DisconnectReason.loggedOut || reason === 401) {
          console.log("🚫 Session logout / invalid");

          deleteSession();
          global.pairingMessage = null;
          reconnectAttempts = 0;
          return;
        }

        reconnectAttempts++;

        if (reconnectAttempts > maxReconnect) {
          console.log("⛔ Stop reconnect (limit)");
          return;
        }

        const delay = Math.min(5000 * reconnectAttempts, 30000);

        console.log(`♻️ Reconnect dalam ${delay / 1000}s`);

        setTimeout(() => startSesi(), delay);
      }
    });

  } catch (err) {
    console.log("❌ Error start session:", err);
    isStarting = false;
  }
};
/* ================= CONNECTION CHECK ================= */
const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    return ctx.reply("❌ WhatsApp belum connect, /connect dulu");
  }
  return next();
};

/* ================= SAFE JSON ================= */
const loadJSON = (file) => {
  try {
    if (!fs.existsSync(file)) return [];

    const data = fs.readFileSync(file, "utf8");
    if (!data) return [];

    return JSON.parse(data);
  } catch (err) {
    console.log("⚠️ JSON corrupt:", file);
    return [];
  }
};

const saveJSON = (file, data) => {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (err) {
    console.log("❌ Failed save JSON:", file, err.message);
  }
};

/* ================= DELETE SESSION ================= */
function deleteSession() {
  try {
    if (!sessionPath || !fs.existsSync(sessionPath)) {
      console.log("⚠️ Session not found.");
      return false;
    }

    fs.rmSync(sessionPath, { recursive: true, force: true });
    console.log("🗑️ Session deleted successfully.");
    return true;

  } catch (err) {
    console.log("❌ Failed delete session:", err.message);
    return false;
  }
}

module.exports = {
  startSesi,
  checkWhatsAppConnection,
  loadJSON,
  saveJSON,
  deleteSession,
};

// ================= USER DATA ================= //

/// ---- LOAD USER DATA ---- ///
let ownerUsers   = loadJSON(ownerFile);
let adminUsers   = loadJSON(adminFile);
let premiumUsers = loadJSON(premiumFile);
let adminList    = [];


loadAdmins();


// ================= MIDDLEWARE ROLE ================= //

/// ---- OWNER ---- ///
const checkOwner = (ctx, next) => {
  if (!ownerUsers.includes(ctx.from.id.toString())) {
    return ctx.reply("Owner Access\nContact @pacenicwlee");
  }
  return next();
};

/// ---- ADMIN ---- ///
const checkAdmin = (ctx, next) => {
  if (!adminList.includes(ctx.from.id.toString())) {
    return ctx.reply("Admin Access\nContact @pacenicwlee");
  }
  return next();
};

/// ---- PREMIUM ---- ///
const checkPremium = (ctx, next) => {
  if (!premiumUsers.includes(ctx.from.id.toString())) {
    return ctx.reply("Premium Access\nContact @pacenicwlee");
  }
  return next();
};


// ================= ADMIN SYSTEM ================= //

/// ---- ADD ADMIN ---- ///
function addAdmin(userId) {
  userId = userId.toString();

  if (!adminList.includes(userId)) {
    adminList.push(userId);
    saveAdmins();
  }
}

/// ---- REMOVE ADMIN ---- ///
function removeAdmin(userId) {
  userId = userId.toString();

  adminList = adminList.filter(id => id !== userId);
  saveAdmins();
}

/// ---- SAVE ADMIN ---- ///
function saveAdmins() {
  try {
    fs.writeFileSync("./database/admins.json", JSON.stringify(adminList, null, 2));
  } catch (err) {
    console.log("❌ Gagal save admin:", err.message);
  }
}

/// ---- LOAD ADMIN ---- ///
function loadAdmins() {
  try {
    if (!fs.existsSync("./database/admins.json")) {
      adminList = [];
      return;
    }

    const data = fs.readFileSync("./database/admins.json", "utf8");
    adminList = JSON.parse(data || "[]");
  } catch (err) {
    console.log("⚠️ Gagal load admin:", err.message);
    adminList = [];
  }
}


// ================= UTIL ================= //

/// ---- SLEEP ---- ///
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/// ---- CHECK PREMIUM ---- ///
function isPremium(userId) {
  return premiumUsers.includes(userId.toString());
}

/// ---- CHECK OWNER ---- ///
function isOwner(id) {
  return ownerUsers.includes(id.toString());
}

/// ---- LOAD OWNER ---- ///
function loadOwner() {
  try {
    if (!fs.existsSync(ownerFile)) return [];
    return JSON.parse(fs.readFileSync(ownerFile, "utf8") || "[]");
  } catch {
    return [];
  }
}


// ================= LOGIN SYSTEM ================= //

function checkPassword(input) {
  return input.trim().toLowerCase() === PASSWORD.toLowerCase();
}

function isLogin(userId) {
  return userLogin.has(userId);
}

function addLogin(userId) {
  userLogin.add(userId);
}
// ================= MIDDLEWARE SYSTEM ================= //

/// ---- Security ------ ///
bot.use((ctx, next) => {
  if (!SECURITY) {
    return ctx.reply("⚠️ Bot sedang OFF / maintenance via GitHub.");
  }
  return next();
});
/// ---- GROUP ONLY ---- ///
bot.use((ctx, next) => {
  const groupMode = getGroupMode();

  if (groupMode === "on" && ctx.chat.type === "private") {
    return; 
  }

  return next();
});


/// ---- SELF / PUBLIC MODE ---- ///
bot.use((ctx, next) => {
  const mode = getMode();

  if (mode === "self" && !isOwner(ctx.from.id)) {
    return; 
  }

  return next();
});
/// -------- ( menu utama ) --------- \\\
const menus = {
  home: (prem) => `
<pre>
     A̷T̷O̷M̷I̷C̷ ̷C̷R̷A̷S̷H̷E̷R̷S̷
━━━━━━━━━━━━━━━━━━
  Ramadhan Special Edition

      SYSTEM CORE
━━━━━━━━━━━━━━━━━━
Owner   : @pacenicwlee
Partner : @canlovelove
System Keamanan : Database 
Access  : Premium Verified
Premium : YES

━━━━━━━━━━━━━━━━━━
     PRICE LIST 
━━━━━━━━━━━━━━━━━━
Script   : 10.000
Reseller : 20.000
Partner  : 30.000
Moderator: 40.000
Owner    : 55.000
━━━━━━━━━━━━━━━━━━
Semangat Puasa, Jangan Mokel!!!

Tap button below to continue →
</pre>
`,

  control: `
<pre>
🛠 SYSTEM CONTROL

Page 2 / 3

    ADMIN COMMAND
━━━━━━━━━━━━━━
• /connect → Add Sender
• /killsesi → Restart Bot
• /self → Keep Online
• /public → Keep Offline 
• /groupon → Group only command
• /groupoff → Group offline command

   USER MANAGEMENT
━━━━━━━━━━━━━━
• /addprem → Add Premium
• /delprem → Remove Premium
• /addadmin → Add Admin
• /deladmin → Remove Admin 
• /info → birkes info
• /runtime → bot time
• /gbinfo → information group

Security Mode : ACTIVE
Network   : Ambalabu 
</pre>
`,

  bug: `
<pre>
BUG TYPE

Silahkan Memilih Bug Dibawah Ini
@pacenicwlee

⚠️ Status : ACTIVE
</pre>
`,

  delay: `
<pre>
     DELAY INVISIBLE

╭───────────────
│/kopiko • Stealth Delay
│/gloweus • Latency Lock
╰───────────────

⚠️ Status : ACTIVE
</pre>
`,

  force: `
<pre>
       FORCLOSE   
╭───────────────
│/overloads • Forclose 
│/xfc • Forclose infinity 
╰───────────────

⚠️ Status : ACTIVE
</pre>
`,

  murbug: `
<pre>
MURBUG MENU

╭───────────────
│/xspam • Force Close Call + Sw
│/xcrash • Force Close Call + Sw
│/xdelay • Invisible Delay
╰───────────────

⚠️ Status : ACTIVE
</pre>
`,

  ios: `
<pre>
        iOS BUGS  
╭───────────────
│/xsixty • iOS System Crash
╰───────────────

⚠️ Status : ACTIVE
</pre>
`,

  android: `
<pre>
      INVISIBLE ANDROID    
╭───────────────
│/xall • Crash Android Invisible
│/execute • Invisible Force Infinity
│/xsql • Invisible Android New
╰───────────────

⚠️ Status : ACTIVE
</pre>
`,

  tools: `
<pre>
⚙️ TOOLS & MENU

Page 6 / 7

     TOOLS FUN
━━━━━━━━━━━━━━
• /brat → text sticker
• /ssiphone → text iphone
• /trackip → ip nick
• /tiktokdl → tiktok no watermark 
• /convert → link url
• /waktu → jam dunia

Security Mode : ACTIVE
</pre>
`,

  thanks: `
<pre>
SUPPORT & CREDITS
Page 8 / 1

KING OWNER
• @pacenicwlee

PRINCESS
• @canlovelove 

Security : ACTIVE
Network  : Ambalabu Xcore
</pre>
`
};
/// ===== HELPER ===== ///
async function sendMenu(ctx, text, keyboard, mode = "HTML") {
  try {
    const msg = ctx.callbackQuery?.message;
    if (!msg) return;

    
    const parseModes = ["HTML", "Markdown", "MarkdownV2"];
    const parse_mode = parseModes.includes(mode) ? mode : "HTML";

    const extra = {
      parse_mode,
      reply_markup: { inline_keyboard: keyboard }
    };

    if (msg.photo) {
      await ctx.editMessageCaption(text, extra);
    } else {
      await ctx.editMessageText(text, extra);
    }
  } catch (e) {
    console.log("Edit error:", e.message);
  }
}

// ===== ANTI-SPAM KLIK SOUND MP33 HAHA=====
var lastClickSound = {};  
var cooldown = 100000;      

// ===== START BOT =====
bot.start(function(ctx) {
  try {
    const args = ctx.message.text.split(" ").slice(1).join(" ");

    
    if (!isLogin(ctx.from.id)) {
      if (!args) {
        return ctx.reply("🔐 Masukkan password!\nContoh: /start Atomic Crashers");
      }

      if (!checkPassword(args)) {
        return ctx.reply("❌ Password salah!");
      }

      addLogin(ctx.from.id);
      return ctx.reply("✅ Password benar!\nSilakan ketik /start lagi");
    }

    const prem = isPremium(ctx.from.id);

    
    ctx.replyWithPhoto(
      { url: "https://files.catbox.moe/sgfbfw.jpg" },
      {
        caption: menus.home(prem),
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "NEXT", callback_data: "control", style: "danger" }],
            [{ text: "SOUND MP3 CLICK", callback_data: "play_sound", style: "primary" }]
          ]
        }
      }
    ).catch(err => {
      console.log("Start error:", err.message);
    });

  } catch (e) {
    console.log("Start catch error:", e.message);
  }
});
// ===== TOMBOL PLAY SOUND ANTI-SPAM BOSS=====
bot.action('play_sound', function(ctx) {
  var userId = ctx.from.id;
  var now = Date.now();

  
  if (lastClickSound[userId] && (now - lastClickSound[userId] < cooldown)) {
    
    return ctx.answerCbQuery('Yah tolol soasik spam tolol donggo yapit kontol', true);
  }

  
  lastClickSound[userId] = now;

  ctx.answerCbQuery()
    .then(function() {
      return ctx.replyWithAudio({
        source: './image/ATOMIC CRASHERS.mp3' 
      }, {
        caption: 'Atomic Crashers'
      });
    })
    .catch(function(err) {
      console.log('Voice note error:', err.message);
      ctx.reply('⚠️ Gagal mainkan suara.');
    });
});

/// ===== HOME BUTTON ===== ///
bot.action("home", async (ctx) => {
  try {
    await ctx.answerCbQuery();

    const prem = isPremium(ctx.from.id);

    const mode = "HTML"; 

    await ctx.editMessageMedia(
      {
        type: "photo",
        media: "https://files.catbox.moe/sgfbfw.jpg",
        caption: menus.home(prem),
        parse_mode: mode,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "➡️ Next", callback_data: "bug" }]
          ]
        }
      }
    );

  } catch (e) {
    console.log("Home error:", e.message);

    
    await ctx.reply("⚠️ Gagal update menu, coba lagi.");
  }
});

/// ===== MENU CONTROL ===== ///
bot.action("control", async (ctx) => {
  await ctx.answerCbQuery();

  return sendMenu(ctx, menus.control, [
    [
      { text: "⬅️ Back", callback_data: "home" }, 
      { text: "➡️ Next", callback_data: "bug" }   
    ]
  ]);
});

/// ===== MENU BUG ===== ///
bot.action("bug", async (ctx) => {
  await ctx.answerCbQuery();

  return sendMenu(ctx, menus.bug, [
    [
      { text: "Delay Invisible", callback_data: "delay" },
      { text: "Force Close", callback_data: "force" }
    ],
    [
      { text: "Murbug", callback_data: "murbug" }
    ],
    [
      { text: "iOS Bugs", callback_data: "ios" },
      { text: "Android Bugs", callback_data: "android" }
    ],
    [
      { text: "👨‍💻 Developer", url: "https://t.me/pacenicwlee" },
      { text: "👥 Room Public", url: "https://t.me/roompublicamba" }
    ],
    [
      { text: "📢 Channel", url: "https://t.me/AboutAmbalabu" }
    ],
    [
      { text: "⬅️ Back", callback_data: "control" }, 
      { text: "➡️ Next", callback_data: "tools" }  
    ]
  ]);
});
/// ===== MENU TOOLS ===== ///
bot.action("tools", async (ctx) => {
  await ctx.answerCbQuery();

  return sendMenu(ctx, menus.tools, [
    [
      { text: "⬅️ Back", callback_data: "bug" },     
      { text: "➡️ Next", callback_data: "thanks" }   
    ]
  ]);
});

/// ===== MENU THANKS ===== ///
bot.action("thanks", async (ctx) => {
  await ctx.answerCbQuery();

  return sendMenu(ctx, menus.thanks, [
    [
      { text: "⬅️ Back", callback_data: "tools" },
      { text: "🏠 Home", callback_data: "home" }
    ]
  ]);
});
/// ===== MENU BUGS ===== ///
bot.action("delay", async (ctx) => {
  await ctx.answerCbQuery(); 
  return sendMenu(ctx, menus.delay, [
    [
      { text: "⬅️ Back", callback_data: "bug" }
    ]
  ]);
});

bot.action("force", async (ctx) => {
  await ctx.answerCbQuery();
  return sendMenu(ctx, menus.force, [
    [
      { text: "⬅️ Back", callback_data: "bug" }
    ]
  ]);
});

bot.action("murbug", async (ctx) => {
  await ctx.answerCbQuery();
  return sendMenu(ctx, menus.murbug, [
    [
      { text: "⬅️ Back", callback_data: "bug" }
    ]
  ]);
});

bot.action("ios", async (ctx) => {
  await ctx.answerCbQuery();
  return sendMenu(ctx, menus.ios, [
    [
      { text: "⬅️ Back", callback_data: "bug" }
    ]
  ]);
});

bot.action("android", async (ctx) => {
  await ctx.answerCbQuery();
  return sendMenu(ctx, menus.android, [
    [
      { text: "⬅️ Back", callback_data: "bug" }
    ]
  ]);
});
/// ------ ( Plugins ) ------- \\\
function getUserId(ctx) {
  const args = ctx.message.text.split(" ");
  if (args.length < 2) return null;

  return args[1].replace(/[^0-9]/g, ""); 
}

// ================= CEK OWNER ================= //
bot.command("cekowner", (ctx) => {
  const data = loadJSON(ownerFile);
  ctx.reply(`ID kamu: ${ctx.from.id}\nOwner list: ${data.join(", ")}`);
});

// ================= ADD ADMIN ================= //
bot.command("addadmin", checkOwner, (ctx) => {
  const userId = getUserId(ctx);
  if (!userId) return ctx.reply("Example: /addadmin 123");

  if (adminUsers.includes(userId)) {
    return ctx.reply(`✅ User ${userId} sudah admin.`);
  }

  adminUsers.push(userId);
  saveJSON(adminFile, adminUsers);

  ctx.reply(`✅ Berhasil tambah ${userId} jadi admin`);
});

// ================= ADD PREMIUM ================= //
bot.command("addprem", checkOwner, (ctx) => {
  const userId = getUserId(ctx);
  if (!userId) return ctx.reply("Example: /addprem 123");

  if (premiumUsers.includes(userId)) {
    return ctx.reply(`✅ User ${userId} sudah premium.`);
  }

  premiumUsers.push(userId);
  saveJSON(premiumFile, premiumUsers);

  ctx.reply(`✅ Berhasil tambah ${userId} jadi premium`);
});

// ================= DELETE ADMIN ================= //
bot.command("deladmin", checkOwner, (ctx) => {
  const userId = getUserId(ctx);
  if (!userId) return ctx.reply("Example: /deladmin 123");

  if (!adminUsers.includes(userId)) {
    return ctx.reply(`❌ User ${userId} tidak ada di admin.`);
  }

  adminUsers = adminUsers.filter(id => id !== userId);
  saveJSON(adminFile, adminUsers);

  ctx.reply(`🚫 Berhasil hapus ${userId} dari admin`);
});

// ================= DELETE PREMIUM ================= //
bot.command("delprem", checkOwner, (ctx) => {
  const userId = getUserId(ctx);
  if (!userId) return ctx.reply("Example: /delprem 123");

  if (!premiumUsers.includes(userId)) {
    return ctx.reply(`❌ User ${userId} tidak ada di premium.`);
  }

  premiumUsers = premiumUsers.filter(id => id !== userId);
  saveJSON(premiumFile, premiumUsers);

  ctx.reply(`🚫 Berhasil hapus ${userId} dari premium`);
});


//----(CASE TOOLS GB)-----//
bot.command("groupon", (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply("❌ Kamu bukan owner!");

  setGroupMode("on");
  ctx.reply("👥 Group Only berhasil diaktifkan.");
});

bot.command("groupoff", (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply("❌ Kamu bukan owner!");

  setGroupMode("off");
  ctx.reply("🌍 Group Only dimatikan.");
});

bot.command("mode", (ctx) => {
  ctx.reply(`⚙️ Mode saat ini: ${getMode().toUpperCase()}`);
});

bot.command("self", (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply("❌ Kamu bukan owner!");

  setMode("self");
  ctx.reply("🔒 Bot sekarang Di kunci Owner.");
});

bot.command("public", (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply("❌ Kamu bukan owner!");

  setMode("public");
  ctx.reply("🌍 Bot Sekarang bisa di akses siapapun.");
});

bot.command("runtime", (ctx) => {
  const uptime = process.uptime();
  const h = Math.floor(uptime / 3600);
  const m = Math.floor((uptime % 3600) / 60);
  const s = Math.floor(uptime % 60);

  ctx.reply(
`┏━━━〔 RUNTIME 〕━━━┓
┃ 🤖 Bot Active
┃ ⏳ ${h} Jam ${m} Menit ${s} Detik
┗━━━━━━━━━━━━━━━━━━┛`
  );
});

bot.command("waktu", (ctx) => {
  const zones = {
    WIB: "Asia/Jakarta",
    WITA: "Asia/Makassar",
    WIT: "Asia/Jayapura"
  };

  let teks = "🕒 Waktu Indonesia\n\n";

  for (let zona in zones) {
    const waktu = new Date().toLocaleTimeString("id-ID", {
      timeZone: zones[zona]
    });
    teks += `${zona} : ${waktu}\n`;
  }

  ctx.reply(teks);
});


bot.command("info", async (ctx) => {
  try {
    let target;

    
    if (ctx.message.reply_to_message) {
      target = ctx.message.reply_to_message.from;
    } else {
      
      target = ctx.from;
    }

    const fullName = `${target.first_name || ""} ${target.last_name || ""}`.trim();
    const username = target.username ? `@${target.username}` : "Tidak ada";
    const userId = target.id;
    const isBot = target.is_bot ? "Ya 🤖" : "Tidak";

    const text = `
<blockquote>『 USER INFO 』</blockquote>

👤 Nama : ${fullName}
🔖 Username : ${username}
🆔 User ID : <code>${userId}</code>
🤖 Bot : ${isBot}
`;

    await ctx.reply(text, { parse_mode: "HTML" });

  } catch (err) {
    console.log("Info error:", err.message);
    ctx.reply("❌ Gagal mengambil info.");
  }
});

bot.command('gbinfo', async (ctx) => {
  try {
    const chat = ctx.chat;

    
    if (chat.type === 'private') {
      return ctx.reply("⚠️ Command ini hanya bisa digunakan di grup!");
    }

    
    const memberCount = await ctx.getChatMembersCount();

    
    const admins = await ctx.getChatAdministrators();
    const adminList = admins.map(a => `- ${a.user.first_name} (${a.user.id})`).join('\n');

    const infoMessage = `
📌 **Group Info**
- Name: ${chat.title}
- ID: ${chat.id}
- Total Members: ${memberCount}
- Admins:
${adminList}
`;

    await ctx.reply(infoMessage, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error(err);
    ctx.reply("❌ Gagal mengambil info grup.");
  }
});

//-------(CASE TOOLS)------//
bot.command("ssiphone", async (ctx) => {
  const text = ctx.message.text.split(" ").slice(1).join(" "); 

  if (!text) {
    return ctx.reply(
      "❌ Format: /ssiphone 18:00|40|Indosat|can5y",
      { parse_mode: "Markdown" }
    );
  }


  let [time, battery, carrier, ...msgParts] = text.split("|");
  if (!time || !battery || !carrier || msgParts.length === 0) {
    return ctx.reply(
      "❌ Format: /ssiphone 18:00|40|Indosat|hai hai`",
      { parse_mode: "Markdown" }
    );
  }

  await ctx.reply("⏳ Wait a moment...");

  let messageText = encodeURIComponent(msgParts.join("|").trim());
  let url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(
    time
  )}&batteryPercentage=${battery}&carrierName=${encodeURIComponent(
    carrier
  )}&messageText=${messageText}&emojiStyle=apple`;

  try {
    let res = await fetch(url);
    if (!res.ok) {
      return ctx.reply("❌ Gagal mengambil data dari API.");
    }

    let buffer;
    if (typeof res.buffer === "function") {
      buffer = await res.buffer();
    } else {
      let arrayBuffer = await res.arrayBuffer();
      buffer = Buffer.from(arrayBuffer);
    }

    await ctx.replyWithPhoto({ source: buffer }, {
      caption: `✅ Ss Iphone By Atomic Crashers ( 🕷️ )`,
      parse_mode: "Markdown"
    });
  } catch (e) {
    console.error(e);
    ctx.reply(" Terjadi kesalahan saat menghubungi API.");
  }
});

bot.command("cekidch", async (ctx) => {
  const input = ctx.message.text.split(" ")[1];
  if (!input) return ctx.reply("Masukkan username channel.\nContoh: /cekidch @namachannel");

  try {
    const chat = await ctx.telegram.getChat(input);
    ctx.reply(`📢 ID Channel:\n${chat.id}`);
  } catch {
    ctx.reply("Channel tidak ditemukan atau bot belum menjadi admin.");
  }
});

bot.command("brat", async (ctx) => {
  const text = ctx.message.text.split(" ").slice(1).join(" ");
  if (!text) return ctx.reply("❌ Masukkan teks!");

  try {
    const apiURL = `https://api.nvidiabotz.xyz/imagecreator/bratv?text=${encodeURIComponent(
      text
    )}&isVideo=false`;

    const res = await axios.get(apiURL, { responseType: "arraybuffer" });
    await ctx.replyWithSticker({ source: Buffer.from(res.data) });
  } catch (e) {
    console.error("Error saat membuat stiker:", e);
    ctx.reply("❌ Gagal membuat stiker brat.");
  }
});

bot.command("tiktokdl", async (ctx) => {
  const args = ctx.message.text.split(" ").slice(1).join(" ").trim();
  if (!args) return ctx.reply("❌ Format: /tiktokdl https://vt.tiktok.com/ZSUeF1CqC/");

  let url = args;
  if (ctx.message.entities) {
    for (const e of ctx.message.entities) {
      if (e.type === "url") {
        url = ctx.message.text.substr(e.offset, e.length);
        break;
      }
    }
  }

  const wait = await ctx.reply("⏳ Sedang memproses video");

  try {
    const { data } = await axios.get("https://tikwm.com/api/", {
      params: { url },
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/ID Safari/537.36",
        "accept": "application/json,text/plain,*/*",
        "referer": "https://tikwm.com/"
      },
      timeout: 20000
    });

    if (!data || data.code !== 0 || !data.data)
      return ctx.reply("❌ Gagal ambil data video pastikan link valid");

    const d = data.data;

    if (Array.isArray(d.images) && d.images.length) {
      const imgs = d.images.slice(0, 10);
      const media = await Promise.all(
        imgs.map(async (img) => {
          const res = await axios.get(img, { responseType: "arraybuffer" });
          return {
            type: "photo",
            media: { source: Buffer.from(res.data) }
          };
        })
      );
      await ctx.replyWithMediaGroup(media);
      return;
    }

    const videoUrl = d.play || d.hdplay || d.wmplay;
    if (!videoUrl) return ctx.reply("❌ Tidak ada link video yang bisa diunduh");

    const video = await axios.get(videoUrl, {
      responseType: "arraybuffer",
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/ID Safari/537.36"
      },
      timeout: 30000
    });

    await ctx.replyWithVideo(
      { source: Buffer.from(video.data), filename: `${d.id || Date.now()}.mp4` },
      { supports_streaming: true }
    );
  } catch (e) {
    const err =
      e?.response?.status
        ? `❌ Error ${e.response.status} saat mengunduh video`
        : "❌ Gagal mengunduh, koneksi lambat atau link salah";
    await ctx.reply(err);
  } finally {
    try {
      await ctx.deleteMessage(wait.message_id);
    } catch {}
  }
});

bot.command("convert", checkPremium, async (ctx) => {
  const r = ctx.message.reply_to_message;
  if (!r) return ctx.reply("❌ Format: /convert ( reply dengan foto/video )");

  let fileId = null;
  if (r.photo && r.photo.length) {
    fileId = r.photo[r.photo.length - 1].file_id;
  } else if (r.video) {
    fileId = r.video.file_id;
  } else if (r.video_note) {
    fileId = r.video_note.file_id;
  } else {
    return ctx.reply("❌ Hanya mendukung foto atau video");
  }

  const wait = await ctx.reply("⏳ Mengambil file & mengunggah ke catbox");

  try {
    const tgLink = String(await ctx.telegram.getFileLink(fileId));

    const params = new URLSearchParams();
    params.append("reqtype", "urlupload");
    params.append("url", tgLink);

    const { data } = await axios.post("https://catbox.moe/user/api.php", params, {
      headers: { "content-type": "application/x-www-form-urlencoded" },
      timeout: 30000
    });

    if (typeof data === "string" && /^https?:\/\/files\.catbox\.moe\//i.test(data.trim())) {
      await ctx.reply(data.trim());
    } else {
      await ctx.reply("❌ Gagal upload ke catbox" + String(data).slice(0, 200));
    }
  } catch (e) {
    const msg = e?.response?.status
      ? `❌ Error ${e.response.status} saat unggah ke catbox`
      : "❌ Gagal unggah coba lagi.";
    await ctx.reply(msg);
  } finally {
    try { await ctx.deleteMessage(wait.message_id); } catch {}
  }
});


bot.command("trackip", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ").filter(Boolean);
  if (!args[1]) return ctx.reply("❌ Format: /trackip 8.8.8.8");

  const ip = args[1].trim();

  function isValidIPv4(ip) {
    const parts = ip.split(".");
    if (parts.length !== 4) return false;
    return parts.every(p => {
      if (!/^\d{1,3}$/.test(p)) return false;
      if (p.length > 1 && p.startsWith("0")) return false; 
      const n = Number(p);
      return n >= 0 && n <= 255;
    });
  }

  function isValidIPv6(ip) {
    const ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(::)|(::[0-9a-fA-F]{1,4})|([0-9a-fA-F]{1,4}::[0-9a-fA-F]{0,4})|([0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,6}::([0-9a-fA-F]{1,4}){0,6}))$/;
    return ipv6Regex.test(ip);
  }

  if (!isValidIPv4(ip) && !isValidIPv6(ip)) {
    return ctx.reply("❌ IP tidak valid masukkan IPv4 (contoh: 8.8.8.8) atau IPv6 yang benar");
  }

  let processingMsg = null;
  try {
  processingMsg = await ctx.reply(`🔎 Tracking IP ${ip} — sedang memproses`, {
    parse_mode: "HTML"
  });
} catch (e) {
    processingMsg = await ctx.reply(`🔎 Tracking IP ${ip} — sedang memproses`);
  }

  try {
    const res = await axios.get(`https://ipwhois.app/json/${encodeURIComponent(ip)}`, { timeout: 10000 });
    const data = res.data;

    if (!data || data.success === false) {
      return await ctx.reply(`❌ Gagal mendapatkan data untuk IP: ${ip}`);
    }

    const lat = data.latitude || "";
    const lon = data.longitude || "";
    const mapsUrl = lat && lon ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(lat + ',' + lon)}` : null;

    const caption = `
<blockquote><b>⚘. Atomic - Crashers 「 ཀ 」</b></blockquote>
⬡ IP: ${data.ip || "-"}
⬡ Country: ${data.country || "-"} ${data.country_code ? `(${data.country_code})` : ""}
⬡ Region: ${data.region || "-"}
⬡ City: ${data.city || "-"}
⬡ ZIP: ${data.postal || "-"}
⬡ Timezone: ${data.timezone_gmt || "-"}
⬡ ISP: ${data.isp || "-"}
⬡ Org: ${data.org || "-"}
⬡ ASN: ${data.asn || "-"}
⬡ Lat/Lon: ${lat || "-"}, ${lon || "-"}
`.trim();

    const inlineKeyboard = mapsUrl ? {
      reply_markup: {
        inline_keyboard: [
          [{ text: "🌍 Location", url: mapsUrl }]
        ]
      }
    } : null;

    try {
      if (processingMsg && processingMsg.photo && typeof processingMsg.message_id !== "undefined") {
        await ctx.telegram.editMessageCaption(
          processingMsg.chat.id,
          processingMsg.message_id,
          undefined,
          caption,
          { parse_mode: "HTML", ...(inlineKeyboard ? inlineKeyboard : {}) }
        );
      } else if (typeof thumbnailurl !== "undefined" && thumbnailurl) {
        await ctx.replyWithPhoto(thumbnailurl, {
          caption,
          parse_mode: "HTML",
          ...(inlineKeyboard ? inlineKeyboard : {})
        });
      } else {
        if (inlineKeyboard) {
          await ctx.reply(caption, { parse_mode: "HTML", ...inlineKeyboard });
        } else {
          await ctx.reply(caption, { parse_mode: "HTML" });
        }
      }
    } catch (e) {
      if (mapsUrl) {
        await ctx.reply(caption + `📍 Maps: ${mapsUrl}`, { parse_mode: "HTML" });
      } else {
        await ctx.reply(caption, { parse_mode: "HTML" });
      }
    }

  } catch (err) {
    await ctx.reply("❌ Terjadi kesalahan saat mengambil data IP (timeout atau API tidak merespon). Coba lagi nanti");
  }
});

// ================= CONNECT ================= //
bot.command("connect", checkOwner, async (ctx) => {
  try {
    if (!sock) {
      return ctx.reply("❌ Socket belum siap. Restart bot dulu.");
    }

    if (isWhatsAppConnected && sock.user) {
      return ctx.reply("✅ WhatsApp sudah terhubung.");
    }

    if (global.pairingMessage) {
      return ctx.reply("⚠️ Pairing masih aktif, tunggu dulu.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
      return ctx.reply("Example: /connect 628xxxx");
    }

    let phoneNumber = args[1].replace(/[^0-9]/g, "");

    if (phoneNumber.startsWith("08")) {
      phoneNumber = "62" + phoneNumber.slice(1);
    }

    if (phoneNumber.length < 10 || phoneNumber.length > 15) {
      return ctx.reply("❌ Nomor tidak valid.");
    }

    await new Promise(r => setTimeout(r, 1000));

    const code = await sock.requestPairingCode(phoneNumber);
    if (!code) return ctx.reply("❌ Gagal ambil pairing code.");

    const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

    const msg = await ctx.replyWithPhoto(
      "https://files.catbox.moe/ep7tzw.jpg",
      {
        caption:
`<blockquote>𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</blockquote>

╭━━━〔 🔗 WHATSAPP PAIRING 〕━━━╮
┃ 📱 Nomor  : ${phoneNumber}
┃ 🔐 Kode   : <code>${formattedCode}</code>
╰━━━━━━━━━━━━━━━━━━━━╯

🟡 <b>Status:</b> Waiting for connection...`,
        parse_mode: "HTML"
      }
    );

    global.pairingMessage = {
      chatId: msg.chat.id,
      messageId: msg.message_id
    };

    setTimeout(() => {
      global.pairingMessage = null;
    }, 60000);

  } catch (err) {
    console.log("Pairing error FULL:", err);
    global.pairingMessage = null;
    ctx.reply("❌ Gagal pairing!");
  }
});


// ================= KILL SESSION ================= //
bot.command("killsesi", checkOwner, async (ctx) => {
  try {
    if (sock) {
      try {
        await sock.logout();
      } catch {}
      sock = null;
    }

    const deleted = deleteSession();
    global.pairingMessage = null;

    if (deleted) {
      ctx.reply("🗑️ Session dihapus, silakan /connect ulang");
    } else {
      ctx.reply("⚠️ Session tidak ditemukan");
    }

  } catch (err) {
    console.log(err);
    ctx.reply("❌ Gagal hapus session");
  }
});
/// --------- ( CASE BUG 1 ) ---------- \\\
bot.command("kopiko", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /kopiko 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Delay invis 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 120; i++) {
    await R9X(sock, target, false);
    await sleep(1000);
  }
});
///============= ( Case bug 2 ) ============///
bot.command("overloads", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /overloads 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Forclose 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 60; i++) {
    await SpamOnly(sock, target);
    await sleep(2000);
  }
});

///============== ( Case bug 3 ) ==========\\
bot.command("xsixty", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /xsixty 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Ios 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 100; i++) {
    await ForceOneLoop(sock, target);
    await sleep(2000);
  }
});

///=============== ( Case bug 4 ) =========\\
bot.command("gloweus", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /Xios 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Ios  
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 80; i++) {
    await FrezeIPhone(target);
    await sleep(1000);
  }
});
///=============== ( Case bug 5 ) =========\\
bot.command("xspam", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /xspam 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Bug spam 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 80; i++) {
    await FrezeIPhone(target);
    await sleep(1000);
  }
});
///=============== ( Case bug 6 ) =========\\
bot.command("xcrash", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /xcrash 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Crash spam 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 80; i++) {
    await FrezeIPhone(target);
    await sleep(1000);
  }
});
///=============== ( Case bug 7 ) =========\\
bot.command("xdelay", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /xdelay 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Delay spam 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 80; i++) {
    await FrezeIPhone(target);
    await sleep(1000);
  }
});
///=============== ( Case bug 8 ) =========\\
bot.command("xsql", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /xsql 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Invisible Andoroid 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 80; i++) {
    await FrezeIPhone(target);
    await sleep(1000);
  }
});
///=============== ( Case bug 9 ) =========\\
bot.command("xall", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /xall 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Crash Andoroid 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 80; i++) {
    await FrezeIPhone(target);
    await sleep(1000);
  }
});
///=============== ( Case bug 10 ) =========\\
bot.command("execute", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /execute 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Invisible ForceInvinity 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 80; i++) {
    await FrezeIPhone(target);
    await sleep(1000);
  }
});
///=============== ( Case bug 10 ) =========\\
bot.command("xfc", checkPremium, checkCooldown, checkWhatsAppConnection, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply("🪧 ☇ Example : /xfc 62xx");

  const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  await ctx.reply(
`<blockquote><b>⸙ 𝑨𝒕𝒐𝒎𝒊𝒄 𝑪𝒓𝒂𝒔𝒉𝒆𝒓𝒔</b></blockquote>

<blockquote><b>
♛ Target : ${q}
♛ Status : Succes Send Bug
♛ Type Bug : Forcelose Infity 
</b></blockquote>`,
  {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⌲ Cek Target", url: `https://wa.me/${q}` }],
      ],
    },
  });

  for (let i = 0; i < 80; i++) {
    await FrezeIPhone(target);
    await sleep(1000);
  }
});
// ------------ (  FUNCTION BUGS ) -------------- \\

// --- Jalankan Bot --- //
(async () => {
  try {
    console.clear();

    console.log("🔐 Checking GitHub config...");
    await checkGitHubConfigRealtime();

   
    if (SECURITY) {
      console.log("🚀 Starting WhatsApp session...");
      await startSesi();
    } else {
      console.log("⚠️ WhatsApp ditahan karena SECURITY OFF");
    }

    
    console.log("🚀 Starting Telegram bot...");

    await bot.launch();

    
    process.once("SIGINT", () => bot.stop("SIGINT"));
    process.once("SIGTERM", () => bot.stop("SIGTERM"));

    console.log("✅ Bot Telegram launched");
    console.log("🟢 System ready");

  } catch (err) {
    console.error("❌ Failed to start:", err);

    
    setTimeout(() => {
      console.log("🔄 Restarting system...");
      process.exit(1);
    }, 3000);
  }
})();