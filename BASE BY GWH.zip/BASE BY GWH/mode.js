{
  "mode": "public"
}